Run ardentryst.py with python (preferrably 2.4+) to play.
If you are in need of help, see help.txt!
Enjoy!
